**Demographic Data:**

<a href="https://population.un.org/wpp/Download/Standard/Population/" target="_blank">UN 2019 Revision of World Population Prospects.</a>

**Social Contacts Data:**

<a href="https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1005697" target="_blank">Prem K, Cook AR, Jit M (2017) Projecting social contact matrices in 152 countries using contact surveys and demographic data.</a>